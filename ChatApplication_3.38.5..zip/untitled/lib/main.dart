import 'package:flutter/material.dart';
import 'package:untitled/UI/sugesstions.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  MyAppState createState() => MyAppState();

  static MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<MyAppState>()!;
}

class MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.light;

  void toggleTheme() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // PURE WHITE THEME
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: Colors.white,
        primaryColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
        ),
        // CHANGED: Use CardThemeData instead of CardTheme
        cardTheme: const CardThemeData(
          color: Color(0xFFF5F5F5),
          elevation: 2,
        ),
      ),
      // PURE BLACK THEME (OLED)
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        // CHANGED: Use CardThemeData instead of CardTheme
        cardTheme: const CardThemeData(
          color: Color(0xFF1A1A1A),
          elevation: 0,
        ),
      ),
      themeMode: _themeMode,
      home: const SuggestionsScreen(),
    );
  }

}
