enum MessageType { user, assistant }

class ChatMessage {
  final String text;
  final MessageType type;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.type,
    required this.timestamp,
  });

  // Helper to check if the message is from the user
  bool get isUser => type == MessageType.user;
}
