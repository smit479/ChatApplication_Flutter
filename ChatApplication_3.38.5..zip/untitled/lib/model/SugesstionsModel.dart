class Suggestion {
  final String id;
  final String title;
  final String description;

  Suggestion({required this.id, required this.title, required this.description});

  // Factory to create a Suggestion from JSON
  factory Suggestion.fromJson(Map<String, dynamic> json) {
    return Suggestion(
      id: json['id'].toString(), // MockAPI often returns IDs as strings
      title: json['title'] ?? '',
      description: json['description'] ?? '',
    );
  }
}

class SuggestionResponse {
  final String status;
  final List<Suggestion> data;
  final int currentPage;

  SuggestionResponse({
    required this.status,
    required this.data,
    required this.currentPage
  });

  // This factory takes the raw List from MockAPI and "wraps" it
  factory SuggestionResponse.fromRawList(List<dynamic> list, int page) {
    return SuggestionResponse(
      status: "success", // Hardcoded to match assignment requirements
      currentPage: page,
      data: list.map((item) => Suggestion.fromJson(item)).toList(),
    );
  }
}
