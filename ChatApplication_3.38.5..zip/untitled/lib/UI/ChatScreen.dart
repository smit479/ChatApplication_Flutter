import 'package:flutter/material.dart';
import 'package:untitled/API/ChatHistoryManager.dart';
import 'package:untitled/model/SugesstionsModel.dart';

import '../model/ChantScreen.dart';

class ChatScreen extends StatefulWidget {
  final String? initialTitle;
  final String? initialDescription;
   List<Suggestion> availableSuggestions;
   ChatScreen({super.key, this.initialTitle, this.initialDescription,required this.availableSuggestions });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    // Logic: User gives Title -> Assistant gives Description
    if (widget.initialTitle != null) {
      _messages.add(ChatMessage(
        text: widget.initialTitle!,
        type: MessageType.user,
        timestamp: DateTime.now(),
      ));

      _simulateAssistantResponse(widget.initialDescription ?? "How can I help?");
    }
  }
// 1. Ensure you pass your list of suggestions to the ChatScreen
// final List<Suggestion> availableSuggestions;

  void _handleSendMessage() {
    final userText = _controller.text.trim();
    if (userText.isEmpty) return;

    setState(() {
      // Add the User Message to the list
      _messages.insert(0, ChatMessage(
        text: userText,
        type: MessageType.user,
        timestamp: DateTime.now(),
      ));
      _isTyping = true;
    });

    _controller.clear();

    // 2. Logic: Search for a matching suggestion title
    String responseText = "I'm not sure how to help with that. Try one of my suggestions!";

    // Find if the user typed a known suggestion title (case-insensitive)
    for (var suggestion in widget.availableSuggestions) {
      if (userText.toLowerCase() == suggestion.title.toLowerCase()) {
        responseText = suggestion.description;
        break;
      }
    }

    // 3. Trigger the Assistant Response
    _simulateAssistantResponse(responseText);
  }

  // void _handleSendMessage() {
  //   if (_controller.text.trim().isEmpty) return;
  //   final text = _controller.text;
  //
  //   setState(() {
  //     _messages.insert(0, ChatMessage(
  //       text: text,
  //       type: MessageType.user,
  //       timestamp: DateTime.now(),
  //     ));
  //     _isTyping = true;
  //   });
  //
  //   _controller.clear();
  //   _simulateAssistantResponse("I am a dummy assistant. You said: $text");
  // }

  void _simulateAssistantResponse(String responseText) {
    setState(() => _isTyping = true);
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _isTyping = false;
          _messages.insert(0, ChatMessage(
            text: responseText,
            type: MessageType.assistant,
            timestamp: DateTime.now(),
          ));
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
        onPopInvoked: (didPop) {
          if (didPop) {
            // Save the chat to history when exiting
            ChatHistoryManager.saveSession(
                widget.initialTitle ?? "New Chat",
                _messages
            );
          }},
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text("Smart Assistant"),backgroundColor:
          Colors.white,),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                reverse: true,
                padding: const EdgeInsets.all(12),
                itemCount: _messages.length + (_isTyping ? 1 : 0),
                itemBuilder: (context, index) {
                  if (_isTyping && index == 0) {
                    return const Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text("Assistant is typing...", style: TextStyle(color: Colors.grey)),
                      ),
                    );
                  }
                  final msg = _messages[_isTyping ? index - 1 : index];
                  return ChatBubble(message: msg);
                },
              ),
            ),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: Colors.white,
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                decoration: InputDecoration(
                  hintText: "Type a message...",
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
                ),
              ),
            ),
            IconButton(icon: const Icon(Icons.send, color: Colors.blue), onPressed: _handleSendMessage),
          ],
        ),
      ),
    );
  }
}

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  const ChatBubble({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: message.isUser ? Colors.blueAccent : Colors.grey[300],
          borderRadius: BorderRadius.circular(15),
        ),
        child: Text(
          message.text,
          style: TextStyle(color: message.isUser ? Colors.white : Colors.black),
        ),
      ),
    );
  }
}
