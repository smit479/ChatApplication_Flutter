import 'package:flutter/material.dart';
import 'package:untitled/API/api.dart';
import 'package:untitled/UI/ChatHistory.dart';
import 'package:untitled/model/SugesstionsModel.dart';
import '../main.dart';
import 'ChatScreen.dart';

class SuggestionsScreen extends StatefulWidget {
  const SuggestionsScreen({super.key});

  @override
  State<SuggestionsScreen> createState() => _SuggestionsScreenState();
}

class _SuggestionsScreenState extends State<SuggestionsScreen> {
  final List<Suggestion> _suggestions = [];
  int _currentPage = 1;
  bool _isLoading = false;
  final int _totalPages = 10; // Adjust based on your MockAPI data count
  static const int _limit = 10;

  @override
  void initState() {
    super.initState();
    _fetchPage(_currentPage);
  }

  // Numbered Pagination Fetch Logic
  Future<void> _fetchPage(int page) async {
    setState(() {
      _isLoading = true;
      _currentPage = page;
      _suggestions.clear(); // Clear previous page data
    });

    try {
      final response = await ApiService().fetchSuggestions(page, _limit);
      if (mounted) {
        setState(() {
          _suggestions.addAll(response.data);
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // Logic to generate 1, 2, ... 10 list
  List<dynamic> _getPaginationNumbers() {
    List<dynamic> pages = [];
    const int margin = 1;

    for (int i = 1; i <= _totalPages; i++) {
      if (i == 1 || i == _totalPages || (i >= _currentPage - margin && i <= _currentPage + margin)) {
        pages.add(i);
      } else if (pages.isNotEmpty && pages.last != "...") {
        pages.add("...");
      }
    }
    return pages;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text("Smart Suggestions"),
          IconButton(
            icon: Icon(Theme.of(context).brightness == Brightness.dark
                ? Icons.light_mode
                : Icons.dark_mode),
            onPressed: () {
              MyApp.of(context).toggleTheme(); // This will work now!
            },
          ),
           InkWell(
               onTap: (){
                 Navigator.push(
                   context,
                   MaterialPageRoute(
                     builder: (context) => ChatHistoryScreen(

                     ),
                   ),
                 );
               },
               child: Icon(Icons.history_outlined,size: 32,color: Colors.black,)),
        ],
      ),backgroundColor:
        Colors.white,),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: _suggestions.length,
        itemBuilder: (context, index) {
          final item = _suggestions[index];
          return Card(
            color: Colors.white,
            elevation: 3,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: ListTile(
              title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(item.description),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => _navigateToChat(item.title, item.description),
            ),
          );
        },
      ),
      bottomNavigationBar: _buildBottomPagination(),
    );
  }

  Widget _buildBottomPagination() {
    final pageNumbers = _getPaginationNumbers();

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Previous Arrow
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: _currentPage > 1 ? () => _fetchPage(_currentPage - 1) : null,
          ),

          // Numbered Buttons
          ...pageNumbers.map((item) {
            if (item == "...") {
              return const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text("...", style: TextStyle(fontWeight: FontWeight.bold)),
              );
            }

            bool isSelected = item == _currentPage;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: InkWell(
                onTap: () => _fetchPage(item),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.blue : Colors.transparent,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.blue),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    "$item",
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),

          // Next Arrow
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: _currentPage < _totalPages ? () => _fetchPage(_currentPage + 1) : null,
          ),
        ],
      ),
    );
  }

  void _navigateToChat(String title, String desc) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          initialTitle: title,
          initialDescription: desc,
          availableSuggestions: _suggestions,
        ),
      ),
    );
  }
}
