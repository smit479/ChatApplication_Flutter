import 'package:flutter/material.dart';
import 'package:untitled/API/ChatHistoryManager.dart';

class ChatHistoryScreen extends StatelessWidget {
  const ChatHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final sessions = ChatHistoryManager.sessions;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: const Text("Chat History"),backgroundColor: Colors.white,),
      body: sessions.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble_outline, size: 60, color: Colors.grey),
            SizedBox(height: 10),
            Text(
              "No chat history yet",

            ),
          ],
        ),
      )
          : ListView.builder(
        itemCount: sessions.length,
        itemBuilder: (context, index) {
          final chat = sessions[index];
          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.message)),
            title: Text(chat['title']),
            subtitle: Text(chat['lastMsg'], maxLines: 1),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // Re-open chat with these messages if you want
            },
          );
        },
      ),
    );
  }
}
