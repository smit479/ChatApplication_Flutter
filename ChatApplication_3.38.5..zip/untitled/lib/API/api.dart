import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/SugesstionsModel.dart';

class ApiService {
  static const String baseUrl = "https://69bbaae60915748735b9dd53.mockapi.io";

  Future<SuggestionResponse> fetchSuggestions(int page, int limit) async {
    final response = await http.get(
      Uri.parse('$baseUrl/suggestions?page=$page&limit=$limit'),
    );

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      // Wraps the raw array from MockAPI into your model
      return SuggestionResponse.fromRawList(body, page);
    } else {
      throw Exception("Failed to load suggestions");
    }
  }
}
