import '../model/ChantScreen.dart';
import '../model/SugesstionsModel.dart';

class ChatHistoryManager {
  // Static list to persist history during the app session
  static List<Map<String, dynamic>> sessions = [];

  static void saveSession(String title, List<ChatMessage> messages) {
    if (messages.isEmpty) return;

    sessions.insert(0, {
      "title": title,
      "date": DateTime.now(),
      "lastMsg": messages.first.text, // Since list is reversed, first is latest
      "messages": List<ChatMessage>.from(messages),
    });
  }
}
